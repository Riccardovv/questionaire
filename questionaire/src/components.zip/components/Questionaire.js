import * as React from "react";
import axios from "axios";
import { useState, useEffect } from "react";
import { Paper, Button } from "@mui/material";
import MultipleChoice from "./Questions/MultipleChoice";
import Boolean from "./Questions/Boolean";
import Numeric from "./Questions/Numeric";

export default function Questionaire() {
  const paperStyle1 = { padding: "20px 25px", width: 600, margin: "20px auto" };

  const paperStyle2 = { padding: "20px 25px", margin: "20px auto" };

  const [questions, setQuestions] = useState([]);
  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    const result = await axios.get("http://localhost:8080/questions/");
    setQuestions(result.data);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
   let form1 = Array.from(document.getElementsByName('questionaire')) 
    
    for (let i = 0; i < form1[0].length; i++) {
        
            if (form1[0][i].type == 'hidden') {
                console.log(form1[0][i].value);
            }
       
        
    }
 };

  return (
    <Paper style={paperStyle1}>
      <form name="questionaire">
        <h2>Blockchain questionaire</h2>
        {questions.map((question) => (
          <Paper style={paperStyle2} key={question.id}>
            {question.type === "Multiple" ? (
              <MultipleChoice key={question.id} question={question} />
            ) : question.type === "Boolean" ? (
              <Boolean key={question.id} question={question.question} />
            ) : (
              <Numeric key={question.id} question={question.question} />
            )}
            <br />
          </Paper>
        ))}
        <Button variant="contained" onClick={handleSubmit}>
          Submit
        </Button>
      </form>
    </Paper>
  );
}
