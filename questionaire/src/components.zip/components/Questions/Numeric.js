import * as React from 'react';
import Slider from '@mui/material/Slider';
import Box from '@mui/material/Box';
export default function Numeric(props) {
    const [answer, setAnswer] = React.useState(0)
    return (
        <>
            <h3 >{props.question}</h3>
            <input type='hidden' value={answer}></input>
            <Slider
                aria-label="Rate"
                defaultValue={1}
                valueLabelDisplay="auto"
                step={1}
                marks
                min={1}
                max={10}
                data-question={props.question}
                onChange={(event) => setAnswer(event.target.value)}
            />
        </>
    );
}