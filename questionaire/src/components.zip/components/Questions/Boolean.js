import * as React from "react";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import { useState } from "react";
import { click } from "@testing-library/user-event/dist/click";

export default function Boolean(props) {
  const [selectedValue, setSelectedValue] = React.useState("Yes");

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };
  return (
    <>
      <h3 value={selectedValue} data-question={props.question}>{props.question}</h3>
      <input type='hidden' value={selectedValue}></input>
      <Radio
        checked={selectedValue === "Yes"}
        onChange={handleChange}
        value="Yes"
        name="radio-buttons"
        inputProps={{ "aria-label": "Yes" }}
      />Yes
      <Radio
        checked={selectedValue === "No"}
        onChange={handleChange}
        value="No"
        name="radio-buttons"
        inputProps={{ "aria-label": "No" }}
      />No
    </>
  );
}
